# Rapport de projet

## 06/09 : 
1. préparation de l'environnement du travail en synchronisant le projet avec NetBeans
2. lecture du code en annexe et du code initial
3. exercice 1 fait et commencement du premier diagramme de classes
La difficulté a été de se familiariser rapidement avec le code pour commencer la conception.

## 07/09 :
1. premiere heure : finition du premier et du second diagramme (exercice 2), 
2. seconde heure : exercices 3,  4 et 5 fait avec le dessin du labyrinthe.
Pas de difficulté particulière pour la réalisation de ces parties.
3. Objectif 1 terminé

## 08/09 :
1. premiere heure : exercice 6 fait, exercice 7 en cours (les tests)
2. seconde heure : exercices 7, 8 fait, exercice 9 en cours (tests et exceptions) <br/>
Difficulté de comprendre la demande du sujet sur la manière d'écrire les tests et les utiliser avec la classe Fichier

## 09/09 :
1. testValide et traitement des exceptions terminés (exercices 8 et 9)
2. Objectif 2 terminé
3. Exercice 10 fait mais à tester, exercice 11 et 12 en cours

## 10/09 :
1. Exercices 11, 12, 13, 14 fait mais à tester avec l'exercice 15 en cours.
2. Exercice 15 terminé
3. Objectif 3 terminé

## 13/09 :
1. Correction au niveau des déplacements, car il ne faut pas créer de nouvelles salles, mais il faut utiliser celles déjà présentes
2. Exercices 15, 16 et 17 fait
3. Objectif 4 terminé

## 14/09 :
1. Début objectif 5
2. Essai pour effectuer des déplacements fluides (exercice 19 en cours)

## 15/09 :
1. Continuité déplacements fluides
2. Il est parfois difficile de critiquer son propre code et de trouver, corriger les erreurs pour régler le problème.

## 16/09 :
1. Déplacements fluides fini pour le héros, mais pas pour les monstres.
2. Gérer la prise en compte du déplacement déjà en cours ou non

## 17/09 :
1. Déplacements fluides enfin terminés pour le héros et les monstres.
2. Exercice 19 terminé. <br/>
Les difficultés rencontrées pour faire les déplacements fluides était la manière de procéder pour stocker la position de départ et la manière d'ajouter à chaque fois un pixel, il aura fallu mettre en place plusieurs attributs pour ceci, il a aussi fallu prendre en compte si le personnage était déjà en cours de déplacement.<br/>

# Difficultés de manière globale :
1. Se familiariser au code dès le départ
2. Conceptualiser de nombreusees classes contenues dans plusieurs packages
3. Comprendre précisément les exigences demandées par le sujet
4. Manipuler les objets et utiliser le polymorphisme de manière pertinente et efficace sans se compliquer


